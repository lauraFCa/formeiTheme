<footer>
    <div class="footer">
        <div class="midias">
            <a href="https://www.instagram.com/formei22/" target="_blank"><i class="bi bi-instagram"></i></a>
            <a href="https://www.linkedin.com/company/formei22/" target="_blank"><i class="bi bi-linkedin"></i></a>
            <a href="https://www.facebook.com/formei22" target="_blank"><i class="bi bi-facebook"></i></a>
        </div>
        <p>Formei®</p>
    </div>


</footer>

<?php wp_footer(); ?>

<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php bloginfo('template_url') ?>/js/jquery.js"></script>
    <script src="<?php bloginfo('template_url') ?>/js/popper.js"></script>
    <script src="<?php bloginfo('template_url') ?>/js/bootstrap.min.js"></script>

</body>

</html>