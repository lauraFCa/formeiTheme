
<footer>
    <div class="footer">
        <div class="midias">
            <a href="https://www.instagram.com/formei22/" target="_blank"><i class="bi bi-instagram"></i></a>
            <a href="https://www.linkedin.com/in/formei-uniacademia-420662240/" target="_blank"><i class="bi bi-linkedin"></i></a>
            <a href="" target="_blank"><i class="bi bi-facebook"></i></a>
        </div>
        <p>Formei®</p>
    </div>

    
</footer>

<?php wp_footer(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script>
window.jQuery || document.write('<script src="<?php bloginfo('template_url');?>/js/vendor/jquery-1.11.2.min.js"><\/script>')
</script>

</body>

</html>