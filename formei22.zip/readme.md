# Tema "Formei"

[Site Formei](https://formei22.000webhostapp.com/)

[Aprender Wordpress (Youtube)](https://www.youtube.com/playlist?list=PLBbHLUbqqCrT1gBZtTminYijo8DVpPynE)

- [X] Barra de menu
- [X] Home page
- [ ] Carrossel com posts de destaque
- [X] Página de um post (individual)
- [X] Página com lista de categorias
- [X] Página com lista de tags
- [ ] Sobre
- [ ] Contato
- [ ] Parte da agenda
   - Vincular ao calendário do email oficial
   - Listar visitas
- [ ] Víncular mídias no rodapé
